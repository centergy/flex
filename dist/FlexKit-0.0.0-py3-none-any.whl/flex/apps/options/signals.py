from flex.signal import signals

install_options = signals.pipeline('options.install_options')
