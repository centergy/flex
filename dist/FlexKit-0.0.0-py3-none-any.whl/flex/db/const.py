
EMPTY = object()

NOTHING = object()

NOT_PROVIDED = object()