try:
	import ordered_set

	__all__ = ['OrderedSet']


	class OrderedSet(ordered_set.OrderedSet):
		pass

except Exception:
	pass

