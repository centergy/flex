from flask.signals import Namespace



_signals = Namespace()

# session_ended = _signals.signal('session-ended')


