from marshmallow.validate import (
	ContainsOnly, Email, Equal, Length, NoneOf, OneOf, Predicate, Range,
	Regexp, URL, Validator
)